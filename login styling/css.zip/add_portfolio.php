<main>
    <h1>Add Portfolio</h1>
    <form class = "add-portfolio" action= "addportfolio.php" method="post">
        <input type="text" name="Stock1" placeholder="ABCD">
        <input type="number" name="count1" placeholder="How many would you like to add?">
        <input type="number" name="value1" placeholder="Value of stock1">
        <input type="text" name="Stock2" placeholder="ABCD">
        <input type="number" name="count2" placeholder="How many would you like to add?">
        <input type="number" name="value2" placeholder="Value of stock2">
        <button type="button">Add Portfolio!</button>
    </form>
</main>